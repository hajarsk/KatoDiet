package exercise;

public class Food {
	String bdate;
	String time;
	String foodcat;
	String desc;
	double calories;
	String userid;
	String total;

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getTotal() {
		return total;
	}

	public void setTotal(String total) {
		this.total = total;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getBdate() {
		return bdate;
	}

	public String getFoodcat() {
		return foodcat;
	}

	public String getDesc() {
		return desc;
	}

	public double getCalories() {
		return calories;
	}

	public void setBdate(String bdate) {
		this.bdate = bdate;
	}

	public void setFoodcat(String foodcat) {
		this.foodcat = foodcat;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public void setCalories(double calories) {
		this.calories = calories;
	}



}
